# anon_ftp_finder

---------------------------------------------------
Anonymous_ftp_scanner is a simple bash script to discover public anonymous ftp's servers.

usage : 
edit the range directly on the file.
make executable : chmod +x scanner.sh
run the script : ./scanner.sh
