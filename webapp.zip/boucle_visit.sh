#!/bin/bash
cat vulnerables_ftp.txt |  while read output
do
    echo ""
    echo "VISITING $output"
    ./visit_ftp.sh $output > $output.log
    echo "-----------------------"
    echo ""
done
