<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="colorlib.com">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,800" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />
  </head>
  <body>
    <div class="s005">
      <form action="index.php" method="post">
        <fieldset>
          <legend>SEARCH FOR AN ANONYMOUS FTP SERVER : </legend>
          <div class="inner-form">
            <div class="input-field">
              <input class="form-control" id="choices-text-preset-values" type="text" name="recherche" placeholder="Type to search..." />
              <button class="btn-search" type="submit" value="OK">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                  <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
                </svg>
              </button>
            </div>
          </div>
          <div class="suggestion-wrap">
            <span></span>
            <div class="result" style="background:white;">
            <?php
            $file = htmlspecialchars($_POST['recherche']);
            $orig = file_get_contents($file);
            $a = htmlentities($orig);
            echo '<code>';
            echo "<p>You search for : <a href='ftp://$file'>ftp://$file</a></p>";
            echo '<pre>';
            echo $a;
            echo '</pre>';
            echo '</code>';
            ?>
            <div>
              <!-- <p>Real time preview : </p>-->
              <?php
              // connect
              // https://stackoverflow.com/questions/3686177/php-to-search-within-txt-file-and-echo-the-whole-line
              $ftp = ftp_connect(htmlspecialchars($_POST['recherche']));
              if (!$ftp) die('could not connect. this ftp server may be offline.');
              // login
              $r = ftp_login($ftp, "anonymous", "");
              if (!$r) die('could not login. this ftp server may be protected.');
              // enter passive mode
              $r = ftp_pasv($ftp, true);
              if (!$r) die('could not enable passive mode.');
              // get listing
              $r = ftp_rawlist($ftp, "/");
              // var_dump($r);
              //foreach ($r as $value) {
              //  echo $value . "<br>";
              //}
               ?>
            </div>
          </div>
          </div>
        </fieldset>
      </form>
    </div>
    <script src="js/extention/choices.js"></script>
    <script>
      var textPresetVal = new Choices('#choices-text-preset-values',
      {
        removeItemButton: true,
      });

    </script>


  </body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
